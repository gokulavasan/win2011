package optimize;

import java.util.List;

public class Optimize {
    
    /*
     * optimizeFiles is a list of names of class that should be optimized
     */
    public static void optimize(List<String> optimizeFiles) {
        //fill me in
    }
}
